Lua libraries for AC CSP, precompiled with LuaJIT 2.1.0-beta3 to speed up Lua initialization. All
source code is available here:
<https://github.com/ac-custom-shaders-patch/acc-lua-sdk>

File “ini_std” is from a different INIpp project, used for expressions when parsing INIpp files:
<https://github.com/ac-custom-shaders-patch/inipp>

However if you’re intending on using those libraries in your own scripts, there are separate
definitions with documentation available in EmmyLua format. Check out “extension/internal/lua-libs”.
Or, better yet, if you're using Visual Studio Code, there is also a small extension which would
automatically detect a library your project would need based on its workspace directories and put it
in Lua extension config. With it, and, of course, with great Lua extension by sumneko, VS Code will
show you available functions, methods, parameters, all with corresponding documentation, and even
highlight possible mistakes.
